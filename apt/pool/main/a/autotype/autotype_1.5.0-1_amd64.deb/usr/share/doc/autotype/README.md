# autotype

A compact Rust typing tool for Windows x64 and Linux x64. Enter text, choose a
**Delay**, click **Start typing**, then focus the destination field. The delay
defaults to 2 seconds and accepts 0.1–3600 seconds, including fractions.

The window starts in dark mode, with a **Light/Dark** toggle, draggable header,
minimize/maximize/close buttons and resizing (the bottom-right grip on Linux).

![Windows interface](docs/ui.png)

Download `autotype.exe` (Windows) or `autotype-linux-x64.tar.gz` (Linux) from the
[releases](https://github.com/Jeremiah-C27/autotype/releases). No Rust installation
is needed. On Linux, extract the archive and run `./autotype` in your desktop session.

## Custom Start and Stop shortcuts

Open **Keys**, turn on **Enable global shortcuts**, and save. Defaults are
**Ctrl+Shift+F6** to start and **Ctrl+Shift+F7** to stop. On Windows/X11, enter your
own combinations, for example `Alt+F8` and `Ctrl+F8`. Start and Stop must differ;
shortcuts already used by another app are rejected.

Enter your text, focus the destination, then press and release the full Start
shortcut. **Start shortcut skips the delay** is on by default, so typing begins
as soon as the shortcut is released. Turn it off to use your selected delay.
The **Start typing** button always uses the selected delay. Stop interrupts both
the countdown and typing; Escape and Cancel remain available.

On Wayland, your desktop assigns the global shortcuts through its permission
dialog and the app shows the approved combinations. Enable keyboard control
first with **Enable typing**. Global shortcuts need a portal backend implementing
[GlobalShortcuts](https://flatpak.github.io/xdg-desktop-portal/docs/doc-org.freedesktop.portal.GlobalShortcuts.html)
as well as RemoteDesktop. **Change in desktop…** needs GlobalShortcuts version 2;
on older implementations, disable and enable shortcuts again to choose new keys.
Release the entire shortcut before typing; Wayland starts on the desktop's
shortcut-release signal.

Shortcut preferences are saved separately, in `%APPDATA%/autotype/settings.json` on
Windows or `$XDG_CONFIG_HOME/autotype/settings.json` on Linux (default
`~/.config/autotype/settings.json`). Entered text is never saved. Wayland also
creates a hidden desktop entry under the user's data directory to identify the
app to desktop portals; it does not add a visible application-menu entry.

## Linux desktops

Both **X11/Xorg** and **Wayland** are supported.

- X11 uses XTest keyboard events. Escape or Cancel stops typing; switching the
  destination window also stops it. Capitals and punctuation use physical Shift.
- Wayland requests **keyboard control only** through the desktop RemoteDesktop
  portal. Click **Enable typing**, approve the desktop dialog, then start typing.
  Cancel works during approval, countdown and typing. Returning to the app stops
  typing; focused Escape also cancels. Revoked permission disables typing promptly.
- **Protect destination** defaults on. GNOME, KDE Plasma, Hyprland and Sway focus
  adapters stop a run when its destination window changes or the adapter fails.
  GNOME needs the bundled companion extension; KDE loads a temporary KWin script.
  See [Wayland setup and limitations](docs/wayland.md). Protection concerns windows,
  not fields or tabs, and is checked before input rather than atomically with it.
- **Remember permission** optionally restores desktop-granted permission across
  launches. Only a private permission token is saved; text stays in memory.
  **Disconnect** ends the session and forgets that token.
- Every Wayland desktop still requires a portal backend with RemoteDesktop
  keyboard control. A focus adapter or Xwayland cannot supply missing permission.
  Disabling protection is an explicit choice; switching destinations can then
  redirect the remaining text.
- Linux binaries are built on Ubuntu 22.04 (glibc 2.35+). The GUI requires desktop
  libraries: OpenGL/EGL, libxkbcommon, and, for X11, libxkbcommon-x11. On Debian/Ubuntu:
  `sudo apt install libgl1 libegl1 libxkbcommon0 libxkbcommon-x11-0`.
  Wayland also needs the session's D-Bus and desktop portal services.

Text stays in memory and is never saved or sent to an external service. Opt-in
permission restoration saves only the private desktop permission token. Keyboard
control is performed locally by Windows, X11, or the desktop portal.

For Proxmox/noVNC, match the local and guest keyboard layouts and Caps Lock state.
Windows and X11 use physical keys when available; characters outside a simple
layout use Unicode or temporary X11 mappings. Remote consoles may not understand
those characters. Wayland's portal delegates key symbols to the compositor.

## apt / winget

Debian/Ubuntu packages, a signed apt feed and Windows winget manifests are built
from the same native binaries. See [package-manager installation and updates](docs/package-managers.md).

## npm / Bun

```sh
npx autotype-rs@1.5.0
# or
bunx --bun autotype-rs@1.5.0
```

The [npm package](npm/README.md) contains both native executables and selects the
one for your platform. It has no runtime dependencies or install scripts.

## Build and verify

Install Rust 1.96.1 and a C compiler (Visual Studio C++ tools for Windows).

```sh
cargo build --locked --release --bin autotype
cargo fmt --check
cargo clippy --locked --all-targets -- -D warnings
cargo test --locked --bin autotype
```

The binary is `target/release/autotype` on Linux or `target/release/autotype.exe`
on Windows. To cross-compile Windows on Linux, install MinGW-w64, add the Rust
`x86_64-pc-windows-gnu` target, and pass `--target x86_64-pc-windows-gnu`.

Windows integration verification: launch the app, then run `cargo run --bin verify`.
Linux X11 verification: `cargo run --bin verify-linux -- target/release/autotype`.
Run this in an isolated X11 session such as Xvfb; it creates temporary test windows.
Wayland protocol verification uses a simulated portal on an isolated D-Bus session:

```sh
cargo build --bin verify-linux
dbus-run-session -- /usr/bin/python3 tests/mock-portal.py target/debug/verify-linux
AUTOTYPE_TEST_DENY=1 dbus-run-session -- /usr/bin/python3 tests/mock-portal.py target/debug/verify-linux
dbus-run-session -- /usr/bin/python3 tests/mock-shortcuts-portal.py target/debug/verify-linux
AUTOTYPE_TEST_DENY=1 dbus-run-session -- /usr/bin/python3 tests/mock-shortcuts-portal.py target/debug/verify-linux
AUTOTYPE_TEST_DUPLICATE_SHORTCUTS=1 dbus-run-session -- /usr/bin/python3 tests/mock-shortcuts-portal.py target/debug/verify-linux
AUTOTYPE_TEST_CLOSE_SHORTCUTS=1 dbus-run-session -- /usr/bin/python3 tests/mock-shortcuts-portal.py target/debug/verify-linux
```

Additional Linux checks:

```sh
for mode in cancel-enable restore v1 revoke owner-loss cancel-send timeout-send release-failure; do
  AUTOTYPE_TEST_MODE="$mode" dbus-run-session -- /usr/bin/python3 tests/mock-portal.py target/debug/verify-linux
done
dbus-run-session -- /usr/bin/python3 tests/mock-focus.py target/debug/verify-linux gnome
dbus-run-session -- /usr/bin/python3 tests/mock-focus.py target/debug/verify-linux kde
node --test tests/desktop-bridges.test.cjs
```

The mock requires python3-gi. It checks keyboard-only permission, denial, key
press/release symbols, global shortcut permission, release timing, Start/Stop,
rebinding signals, revocation, application identity and session cleanup. It does
not replace real compositor
testing; real GNOME/KDE Wayland verification is still needed.

CI builds/tests Windows and Linux, verifies X11 and the portal protocol, and packs
both binaries for npm. To build locally, run `npm run build:native --prefix npm`
on Linux, then `npm run build:native --prefix npm -- --target x86_64-pc-windows-gnu`
with MinGW available. `npm pack` in `npm/` validates both binaries, versions,
permissions and SHA-256 hashes.

## Updating

A separate self-update command is unnecessary for the npm/Bun package. Ask the
package manager for the latest release:

```sh
npx autotype-rs@latest
bunx --bun autotype-rs@latest
# Update a global npm installation:
npm install -g autotype-rs@latest
```

An explicit version such as `@1.3.2` stays pinned. Updating an installed package
also replaces its bundled executable; close the app before updating. Standalone
users download and replace the executable from GitHub releases.
